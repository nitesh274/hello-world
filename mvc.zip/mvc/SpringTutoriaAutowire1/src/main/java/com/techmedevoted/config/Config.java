package com.techmedevoted.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;



@Configuration
@ComponentScan("com.techmedevoted.model")
public class Config {
	

}
