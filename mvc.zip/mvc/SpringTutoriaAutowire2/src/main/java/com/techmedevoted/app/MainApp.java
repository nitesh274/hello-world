package com.techmedevoted.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.techmedevoted.config.Config;
import com.techmedevoted.service.PaymentGateway;

public class MainApp {
	   public static void main(String[] args) {
	      ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
	      
		   /*AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		   context.register(HelloWorldConfig.class);
		   context.refresh();*/
	    
	      PaymentGateway payment=context.getBean(PaymentGateway.class);
	      payment.setOrder();
	      payment.showOrder();
	     
	    
	   }
	}