package com.techmedevoted.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techmedevoted.model.Order;

@Service
public class PaymentGateway {
	 
    @Autowired
    private Order order;
    
    public void setOrder(){
    	order.setItem("Pen");
    	order.setPrice("25");
    }
     
   public void showOrder(){
	  System.out.println(order.getItem()); 
	  System.out.println(order.getPrice()); 
   }
}