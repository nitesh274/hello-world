package com.techmedevoted.mvc.model;

public class Employee {
	
	private String name;
	private int empID;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	
	

}
