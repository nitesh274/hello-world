package com.techmedevoted.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.techmedevoted.mvc.service.EmpService;

@Controller
public class GreetController {
	
	@Autowired
	EmpService empService;
	
    @RequestMapping(path= "/greet/{name}",method=RequestMethod.GET)    
    public String greet(@PathVariable String name, ModelMap model){
        String greet =" Hello !!!" + name + " How are You?";
       
        String eName=empService.empDetails().getName();
        int eId=empService.empDetails().getEmpID();
        
        model.addAttribute("greet", greet);
        model.addAttribute("eName", eName);
        model.addAttribute("eId", eId);
        
        return "greet";
    }
}