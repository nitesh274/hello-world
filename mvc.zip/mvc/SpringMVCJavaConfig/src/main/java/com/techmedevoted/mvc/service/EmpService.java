package com.techmedevoted.mvc.service;

import org.springframework.stereotype.Service;

import com.techmedevoted.mvc.model.Employee;

@Service
public class EmpService {
	
	public Employee empDetails(){
		
		Employee e=new Employee();
		e.setEmpID(274);
		e.setName("Hero");
		return e;
		
	}

}
