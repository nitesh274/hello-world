package com.techmedevoted.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.techmedevoted.config.Config;
import com.techmedevoted.model.Address;
import com.techmedevoted.model.Employee;

public class MainApp {
	   public static void main(String[] args) {
	      ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
	      
		   /*AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		   context.register(HelloWorldConfig.class);
		   context.refresh();*/
	    
	      Employee emp=context.getBean(Employee.class);
	      Address add=context.getBean(Address.class);
	     /* emp.setId(12);
	      emp.setName("nits");
	      add.setCity("Bangalore");
	      add.setState("KA");
	      add.setCountry("India");
	      emp.setAddress(add);*/
	      
	     System.out.println(emp.getId());
	     System.out.println(emp.getName());
	     System.out.println(emp.getAddress());
	      
	    
	   }
	}