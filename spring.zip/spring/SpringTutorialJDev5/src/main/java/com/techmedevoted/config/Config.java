package com.techmedevoted.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.techmedevoted.model.Address;
import com.techmedevoted.model.Employee;



@Configuration
public class Config {
	
	@Bean
	public Address a1(){
		Address add=new Address();
		add.setCity("Bangalore");
		add.setCountry("India");
		add.setState("KA");
		return add;
	}
	
	@Bean
	public Employee e(){
		Employee emp=new Employee();
		emp.setId(15);
		emp.setName("Nitesh");
		emp.setAddress(a1());
		return emp;
	}

}
