package com.techmedevoted.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.techmedevoted.model.HelloWorld;

@Configuration
public class HelloWorldConfig {
	
	@Bean
	public HelloWorld helloWorld(){
		return new HelloWorld();
	}

}
