package com.techmedevoted.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.techmedevoted.config.HelloWorldConfig;
import com.techmedevoted.model.HelloWorld;

public class MainApp {
	   public static void main(String[] args) {
	      ApplicationContext context = new AnnotationConfigApplicationContext(HelloWorldConfig.class);
	      
		   /*AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		   context.register(HelloWorldConfig.class);
		   context.refresh();*/
	    
	     HelloWorld helloWorld=context.getBean(HelloWorld.class);
	     helloWorld.setMessage("Hello Java config");
	     helloWorld.getMessage();
	   }
	}