package stack;
//using linked list
import java.util.NoSuchElementException;

class Node {
	int data;
	Node next;

	public Node(int d, Node n) {
		data = d;
		next = n;
	}
	Node(){
		next=null;
		data=0;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	public Node getNext() {
		return next;
	}
	public void setNext(Node next) {
		this.next = next;
	}
	
	
}
public class Stack {
	Node top;
	int size;
	
	public Stack(){
		top=null;
		size=0;
	}
	
	public boolean isEmpty(){
		return top==null;
	}

	public int size(){
		return size;
	}
	
	
	public void push(int data){
		Node node=new Node(data,null);
		if(top==null){
			top=node;
		}
		else{
			node.setNext(top);
			top=node;
		}
		size++;
	}
	
	
	 public int pop()
	    {
	        if (isEmpty() )
	            throw new NoSuchElementException("Underflow Exception") ;
	        Node ptr = top;
	        top = ptr.getNext();
	        size-- ;
	        return ptr.getData();
	    }  
	 
	 public int peek()
	    {
	        if (isEmpty() )
	            throw new NoSuchElementException("Underflow Exception") ;
	        return top.getData();
	    }   
	
	public void display()
    {
        System.out.print("\nStack = ");
        if (size == 0) 
        {
            System.out.print("Empty\n");
            return ;
        }
        Node ptr = top;
        while (ptr != null)
        {
            System.out.print(ptr.getData()+" ");
            ptr = ptr.getNext();
        }
        System.out.println();        
    }
	
	
	public static void main(String[] args) {
		Stack stack=new Stack();
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		stack.push(5);
		stack.push(6);
		stack.display();
		System.out.println("popped element "+stack.pop());
		stack.display();
		System.out.println("peeked element "+stack.peek());
	}
}

