package linkedList;

public class LinkedListDemo {
	Node head;

	class Node {
		int data;
		Node next;

		Node(int d) {
			data = d;
		}
	}

}
