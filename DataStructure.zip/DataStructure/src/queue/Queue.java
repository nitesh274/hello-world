package queue;

import java.util.NoSuchElementException;

//using linked list

class Node {
	int data;
	Node next;

	public Node(int d, Node n) {
		data = d;
		next = n;
	}

	Node() {
		next = null;
		data = 0;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	public Node getNext() {
		return next;
	}

	public void setNext(Node next) {
		this.next = next;
	}

}

public class Queue {

	Node front, rear;
	int size;

	public Queue() {
		front = null;
		rear = null;
		size = 0;

	}

	public boolean isEmpty() {
		return front == null;
	}

	public int getSize() {
		return size;
	}

	public void insert(int data) {
		Node node = new Node(data, null);
		if (rear == null) {
			front = node;
			rear = node;

		} else {
			rear.setNext(node);
			rear = rear.getNext();
		}
		size++;
	}

	 public int remove()
	    {
	        if (isEmpty() )
	            throw new NoSuchElementException("Underflow Exception");
	        Node ptr = front;
	        front = ptr.getNext();        
	        if (front == null)
	            rear = null;
	        size-- ;        
	        return ptr.getData();
	    }   
	 
	 public int peek()
	    {
	        if (isEmpty() )
	            throw new NoSuchElementException("Underflow Exception");
	        return front.getData();
	    }   
	 
	public void display() {
		System.out.println("\nQueue is");
		if (size == 0) {
			System.out.println("empty queue");
			return;
		}

		Node node = front;
		while (node != rear.getNext()) {
			System.out.print(node.getData() + " ");
			node = node.getNext();
		}
		System.out.println();
	}

	public static void main(String[] args) {
		Queue q = new Queue();
		q.insert(1);
		q.insert(2);
		q.insert(3);
		q.insert(4);
		q.insert(5);
		q.display();
		q.remove();
		q.display();
	}
}
