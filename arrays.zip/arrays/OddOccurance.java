package arrays;
/*
Given an array of positive integers. All numbers occur even number of times except one number which occurs odd number 
of times. Find the number in O(n) time & constant space.
 */
public class OddOccurance {

	public static void main(String[] args) {
		OddOccurance odd=new OddOccurance();
		int arr[]=new int[]{1,1,3,4,5,3,5,4,5,5,1};
		odd.findOddOccurance(arr);

	}

	public void findOddOccurance(int[] arr) {
		int res=0;
		for(int i=0;i<arr.length;i++){
			res=(res ^ arr[i]);
		}
		System.out.println(res);
	}

}
