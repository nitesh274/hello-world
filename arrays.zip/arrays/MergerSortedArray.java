package arrays;

public class MergerSortedArray {

	void moveToEnd(int mPLUSn[]){
		int j=mPLUSn.length-1;
		for(int i=mPLUSn.length-1;i>=0;i--){
			if(mPLUSn[i]!=-1){
				mPLUSn[j]=mPLUSn[i];
				j--;
			}
		}
	}
	
	void merge(int mPLUSn[], int arr[] ){
		
		int n=arr.length-1;
		int m=mPLUSn.length-n;
		int i=n;
		int k=0;
		int j=0;
		while(k<(m+n)){
			if((i<(m+n) && mPLUSn[i]<=arr[j]) || (j==n)){
				mPLUSn[k]=mPLUSn[i];
				k++;
				i++;
			}
			else // Otherwise take element from N[]
            {
				mPLUSn[k] = arr[j];
                k++;
                j++;
            }
        }
    }
	void printArray(int arr[]){
		for(int i=0;i<arr.length;i++){
			System.out.println(arr[i]);
		}
	}
	public static void main(String[] args) {
		int mPLUSn[]=new int[10];
		mPLUSn[0]=1;
		mPLUSn[2]=4;
		mPLUSn[4]=7;
		mPLUSn[6]=11;
		mPLUSn[7]=14;
		mPLUSn[8]=17;
		
		int arr[] = {5, 7, 9};
		MergerSortedArray array=new MergerSortedArray();
		array.moveToEnd(mPLUSn);
		array.merge(mPLUSn, arr);
		array.printArray(mPLUSn);

	}

}
