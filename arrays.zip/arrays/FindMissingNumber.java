package arrays;
/*
You are given a list of n-1 integers and these integers are in the range of 1 to n. 
There are no duplicates in list. One of the integers is missing in the list. Write an efficient code to 
find the missing integer.


 */
public class FindMissingNumber {

	public static void main(String[] args) {
		int arr[]=new int[]{1,2,3,4,5,6,7,8,9};
		findMissingNo(arr);

	}

	private static void findMissingNo(int[] arr) {
		int n=arr.length+1;
		int sum=n*(n+1)/2;
		for(int i=0;i<arr.length;i++){
			sum=sum-arr[i];
		}
		System.out.println(sum);
		
	}

}
