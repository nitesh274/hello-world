package arrays;

/*
Given an array A[] and a number x, check for pair in A[] with sum as x
find sum as 16
 */
public class PrintPairs {

	public static void main(String[] args) {
		int arr[] = { 10, 8, 45, 6, 10, 8 };
		int sum = 16;
		printPair(arr, sum);

	}

	private static void printPair(int[] arr, int sum) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++)
				if (arr[i] + arr[j] == sum) {
					System.out.println(arr[i] + " " + arr[j]);
				}
		}

	}

}
