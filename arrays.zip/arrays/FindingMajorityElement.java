package arrays;

import java.util.HashSet;
import java.util.Set;

/* Program for finding out majority element in an array 
 A majority element in an array A[] of size n is an element that appears more than n/2 times 
 (and hence there is at most one such element).
 */

public class FindingMajorityElement {

	public static void main(String[] args) {
		int arr[] = { 10, 8, 6, 10, 8, 6, 6, 1, 6, 6, 6, 6,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5 };
		findMajorityMthd1(arr);

	}

	private static void findMajorityMthd1(int[] arr) {
		int count = 0;
		Set<Integer> s = new HashSet<>();
		for (int i : arr) {
			s.add(i);
		}

		for (int x : s) {
			for (int j = 0; j < arr.length; j++) {
				if (x == arr[j]) {
					count++;
				}
			}

			if (count > (arr.length / 2)) {
				System.out.println(x + " is majority element ");
			}
			count = 0;
		}

	}

}
