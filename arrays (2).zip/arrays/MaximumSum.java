package arrays;
/*Function to return max sum such that no two elements
are adjacent */
public class MaximumSum {
	
	int findMax(int arr[], int n){
		int incl=arr[0];
		int excl=0;
		int excl_new;
		
		for(int i=1;i<n;i++){
			excl_new=(incl>excl)?incl:excl;
			incl=excl+arr[i];
			excl=excl_new;
		}
		return ((incl>excl)?incl:excl);
		
		
	}

	public static void main(String[] args) {
		int arr[]=new int[]{1,23,4,25,21,9,5,6};
		int n=arr.length;
		MaximumSum sum=new MaximumSum();
		System.out.println(sum.findMax(arr, n));

	}

}
