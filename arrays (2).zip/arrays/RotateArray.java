package arrays;

public class RotateArray {

	
	public static void main(String[] args) {
		int arr[] = new int[] { 1, 2, 3, 4, 5, 6, 7};
		int size=arr.length;
		int rotate[]=leftRotate(arr,5,7);
		for(int i=0;i<size;i++){
			System.out.print(rotate[i]+" ");
		}
		

	}

	static int[] leftRotate(int arr[], int d, int n) 
    {
        int i;
        for (i = 0; i < d; i++){
            leftRotatebyOne(arr, n);
        }
		return arr;
    }
 
    static void leftRotatebyOne(int arr[], int n) 
    {
        int i, temp;
        temp = arr[0];
        for (i = 0; i < n - 1; i++)
            arr[i] = arr[i + 1];
        arr[i] = temp;
    }

}
