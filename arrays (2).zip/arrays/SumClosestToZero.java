package arrays;

public class SumClosestToZero {

	static void sumClosesToZero(int arr[]) {
		int min_sum = arr[0] + arr[1];
		int min_l = 0;
		int min_r = 1;
		int sum = 0;
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				sum = arr[i] + arr[j];
				if (Math.abs(sum) < Math.abs(min_sum)) {
					min_sum = sum;
					min_l = i;
					min_r = j;

				}

			}
		}
		System.out.println(arr[min_l] + " " + arr[min_r]);
	}

	public static void main(String[] args) {
		int arr[] = new int[] { 1, 60, -10, 70, -80, 85 };
		sumClosesToZero(arr);

	}

}
